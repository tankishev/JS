import { render as litRender } from '../node_modules/lit-html/lit-html.js';
import { request } from './requests.js';
import page from '../node_modules/page/page.mjs';
import { views } from '../views/views.js';

import { loadView as loadNav } from './controlers/nav.js';
import { loadView as loadLogin, logout } from './controlers/login.js';
import { loadView as loadRegister } from './controlers/register.js';
import { loadView as loadHome } from './controlers/dashboard.js';
import { loadView as loadDetails} from './controlers/details.js';
import { loadView as loadAddBook } from './controlers/create.js';
import { loadView as loadMyBooks } from './controlers/mybooks.js';

const nav = document.getElementById('site-header');
const main = document.getElementById('site-content');

function start(){
    page(setUpPageCTX);
    page(loadNav);
    page('/login', loadLogin);
    page('/register', loadRegister);
    page('/logout', logout);
    page('/home', loadHome);
    page('/', '/home');
    page('/details/:bookId', loadDetails);
    page('/add', loadAddBook);
    page('/mybooks', loadMyBooks);
    page.start();
}

start();

function setUpPageCTX(ctx, next){
    ctx.views = views;
    ctx.render = litRender;
    ctx.main = main;
    ctx.nav = nav;
    ctx.request = request;
    next();
}