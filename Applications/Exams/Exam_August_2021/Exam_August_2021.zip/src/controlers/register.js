export function loadView(ctx, next){
    const {views, render, main, request} = ctx;
    render(views.registerView(onSubmit), main);
    next();

    async function onSubmit(ev){
        ev.preventDefault();
        const form = document.querySelector('form');
        try {
            const formData = new FormData(form);
            const values = Array.from(formData.values());
            if (values.some(v => v =='')){
                throw new Error('All fields are required');
            };
            const regData = Object.fromEntries(formData.entries());
            if (regData["confirm-pass"] != regData['password']){
                throw new Error('Passwords do not match');
            }
            const {email, password} = regData;
            await request('register', {data:{email, password}});
            let user_email = sessionStorage.getItem('email');
            if (user_email =! null){
                window.location.pathname = '/home';
            };
        } catch (error) {
            alert(error.message);
        } finally {
            form.reset();
        }
    }
}