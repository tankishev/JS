export async function loadView(ctx, next){
    const {views, main, render, request, params} = ctx;
    const bookId = params.bookId;
    const [bookData, likes] = await Promise.all([
        request('getBook', {reqIDs:{bookId}}),
        request('getLikes', {reqIDs:{bookId}})
    ]);
    bookData['likes'] = likes;
    const userId = sessionStorage.getItem('user_id');
    const boolIsOwner = (bookData._ownerId == userId);

    const funcs = {
        edit: (ev) => {
            ev.preventDefault();
            render(views.editView(bookData, onSubmit), main);

            async function onSubmit(ev){
                ev.preventDefault();
                const form = document.querySelector('form');
                const formData = new FormData(form);
                try {
                    if (Array.from(formData.values()).some(el => el == '')){
                        throw new Error('Please fill all fields');
                    }
                    const data = Object.fromEntries(formData.entries());
                    const responseData = await request('editBook', {data, reqIDs:{bookId}});
                    window.location.pathname = `/details/${bookId}`;
                } catch (error) {
                    alert(error.message);
                }
            }
        },
        remove: (ev) => {
            ev.preventDefault();
            if (confirm('Are you sure you want to delete this book?')){
                request('deleteBook', {reqIDs:{bookId}});
                window.location.pathname = '/home';
            }
        },
        like : (ev) => {
            ev.preventDefault();
            request('like', {data:{bookId}});
            window.location.pathname = `/details/${bookId}`;
        }
    }

    render(views.detailsView(bookData, funcs, boolIsOwner), main);
    if (userId == null ){
        document.getElementById('btnLike').remove();

    } else {
        const userLikes = await request('getUserLikes', {reqIDs:{bookId, userId}})
        if (userLikes > 0){
            document.getElementById('btnLike').remove();
        }
    }
}