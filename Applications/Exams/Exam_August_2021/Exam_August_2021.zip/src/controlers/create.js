export function loadView(ctx, next){
    const {render, main, views, request} = ctx;
    render(views.createView(onSubmit), main);

    async function onSubmit(ev){
        ev.preventDefault();
        const form = document.querySelector('form');
        const formData = new FormData(form);
        try {
            if (Array.from(formData.values()).some(el => el == '')){
                throw new Error('Please fill all fields');
            }
            const data = Object.fromEntries(formData.entries());
            const responseData = await request('createBook', {data});
            window.location.pathname = `/home`;
        } catch (error) {
            alert(error.message);
        }
    }
}