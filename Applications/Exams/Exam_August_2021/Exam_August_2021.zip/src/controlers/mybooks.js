export async function loadView(ctx, next){
    const {views, main, render, request} = ctx;
    const userId = sessionStorage.getItem('user_id')
    const data = await request('loadMyBooks', {reqIDs:{userId}});
    render(views.myBooksView(data), main);
}