export function loadView(ctx, next){
    const {views, render, nav} = ctx;
    const email = sessionStorage.getItem('email');
    render(views.navigationView(email), nav);
    next();
}