export function loadView(ctx, next){
    const {views, render, main, request} = ctx;
    render(views.loginView(onSubmit), main);
    next();

    async function onSubmit(ev){
        ev.preventDefault();
        const form = document.querySelector('form');
        try {
            const formData = new FormData(form);
            const values = Array.from(formData.values());
            if (values.some(v => v =='')){
                throw new Error('Please fill both email and password');
            };
            const data = Object.fromEntries(formData.entries());
            await request('login', {data});
            let email = sessionStorage.getItem('email');
            if (email =! null){
                window.location.pathname = '/home';
            };
        } catch (error) {
            alert(error.message);
        } finally {
            form.reset();
        }
    }
}

export function logout(ctx, next){
    const {request} = ctx;
    request('logout');
    window.location.pathname = '/home';
}