export async function loadView(ctx, next){
    const {views, main, render, request} = ctx;
    const data = await request('loadBooks');
    render(views.dashboardView(data), main);
}